@extends('laravel-crm::layouts.app')

@section('content')
    
    @include('laravel-crm::teams.partials.card-edit')
    
@endsection