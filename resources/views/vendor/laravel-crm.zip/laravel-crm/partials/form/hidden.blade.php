<input id="input_{{ $name }}" type="hidden" name="{{ $name }}" value="{{ $value ?? null }}" @include('laravel-crm::partials.form.attributes') />
       