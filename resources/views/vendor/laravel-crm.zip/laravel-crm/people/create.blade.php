@extends('laravel-crm::layouts.app')

@section('content')

  @include('laravel-crm::people.partials.card-create')

@endsection