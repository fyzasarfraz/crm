@extends('laravel-crm::layouts.app')

@section('content')
    
    @include('laravel-crm::leads.partials.card-convert')
    
@endsection