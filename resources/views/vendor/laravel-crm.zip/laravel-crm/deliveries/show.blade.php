@extends('laravel-crm::layouts.app')

@section('content')

    @include('laravel-crm::deliveries.partials.card-show')

@endsection
