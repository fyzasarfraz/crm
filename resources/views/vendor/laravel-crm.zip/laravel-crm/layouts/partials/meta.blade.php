<meta name="date_format" content="{{ $dateFormat }}" />
<meta name="time_format" content="{{ $timeFormat }}" />