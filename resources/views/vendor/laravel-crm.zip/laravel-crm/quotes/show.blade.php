@extends('laravel-crm::layouts.app')

@section('content')
    
    @include('laravel-crm::quotes.partials.card-show')

@endsection